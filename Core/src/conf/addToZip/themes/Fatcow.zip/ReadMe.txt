# classic color keys and values from HO V1.431
black=0,0,0
white=255,255,255
light_gray=192,192,192
dark_gray=64,64,64
gray=128,128,128
ho_gray1=230,230,230
lightGreen=220,220,255
green=0,0,255
lightYellow=255,200,255
yellow=255,0,255


shirt=ho_gray1
shirt.wb=0,0,220
shirt.subFor=255,200,200
shirt.kee=black
shirt.subKee=200,200,200
shirt.cd=0,220,0
shirt.win=220,0,140
shirt.subMid=255,180,255
shirt.subDef=200,255,200
shirt.subWin=255,180,225
shirt.for=220,0,0
shirt.mid=220,0,220

league.fg=black
league.demoted.bg=255,220,220
league.relegation.bg=lightYellow
league.bg=white
league.title.bg=ho_gray1
league.promoted.bg=lightGreen

leaguehistory.line1.fg=0,0,255
leaguehistory.line2.fg=0,255,255
leaguehistory.line3.fg=128,128,128
leaguehistory.line4.fg=black
leaguehistory.line5.fg=255,0,200
leaguehistory.line6.fg=255,175,175
leaguehistory.line7.fg=255,0,0
leaguehistory.line8.fg=255,255,0
leaguehistory.cross.fg=64,64,64
leaguehistory.grid.fg=light_gray

stat.incomeTemporary=0,180,0
stat.setPieces=0,255,255
stat.incomeFinancial=0,120,60
stat.passing=0,0,255
stat.form=255,175,175
stat.loyalty=180,0,180
stat.leadership=128,128,128
stat.incomeSpectators=0,0,180
stat.keeper=black
stat.incomeSponsors=0,60,120
stat.rating=100,0,200
stat.costTemporary=180,0,108
stat.costStaff=180,0,144
stat.fans=0,255,255
stat.scoring=255,0,0
stat.winLost=128,128,128
stat.incomeSum=0,0,255
stat.costArena=180,0,0
stat.cash=black
stat.total=128,128,128
stat.confidence=0,255,255
stat.costSum=255,0,0
stat.mood=255,175,175
stat.costsPlayers=180,0,36
stat.rating2=black
stat.stamina=255,255,0
stat.costsYouth=180,0,180
stat.experience=64,64,64
stat.winger=255,0,200
stat.costFinancial=180,0,72
stat.wage=150,20,20
stat.playmaking=yellow
stat.marketValue=0,255,0
stat.defending=0,255,0

panel.bg=white
panel.border=dark_gray
label.error.fg=255,0,0
label.success.fg=green
label.onGreen.fg=white
label.fg=black

table.selection.bg=235,235,235
table.selection.fg=label.fg


tableEntry.fg=black
tableEntry.bg=white
tableEntry.improvement.fg=0,0,200
tableEntry.decline.fg=200,0,0
skillEntry2.bg=gray

button.bg=white
button.assist.bg=yellow

list.fg=black
list.current.fg=0,150,0
list.selection.bg=220,255,220

matchtype.bg=white
matchtype.friendly.bg=white
matchtype.cup.bg=l200,255,200
matchtype.qualification.bg=255,200,200
matchtype.int.normal.bg=light_gray
matchtype.masters.bg=light_gray
matchtype.national.bg=220,255,220
matchtype.intFriendly.bg=white
matchtype.league.bg=lightYellow

matchHighlight.failed.fg=gray

selectorOverlay.bg=255,10,10,40
selectorOverlay.selected.bg=10,255,10,40

lineup.pos.min.border=light_gray
lineup.pos.min.bg=panel.bg

player.skill.bg=lightYellow
player.pos.bg=220,255,220
player.subpos.bg=235,255,235
player.skill.special.bg=lightGreen
player.old.fg=gray

team.fg=50,150,50

